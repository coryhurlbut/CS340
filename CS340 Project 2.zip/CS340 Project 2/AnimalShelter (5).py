# -*- coding: utf-8 -*-

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        #USER = 'aacuser'
        #PASS = 'SNHU1234'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32186
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (username,password,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
 
# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            try:
                self.database.animals.insert_one(data) 
                return ("successfully inserted", data)
            except Exception:
                return "failed to insert"
                
        else:
            raise Exception("Nothing to save, because data parameter is empty")

# Create method to implement the R in CRUD.
    def read(self, searchParam):
        result = {}
        if searchParam == {}:
            result = list(self.database.animals.find({}))
        else:
            result = list(self.database.animals.find(searchParam))
            if result is None:
                result = "Not found"
        return result
            
#Method to update database content
    def update(self, query, data):
        try:
            if data is not None:
                result = self.database.animals.update_one({'_id': ObjectId(query)}, 
                                                {'$set': data})
                return result
            else:
                raise Exception("No data")
        except Exception:
            return "Failed to find and modify"

#Method to delete entries from the database
    def delete(self, query):
        try:
            result = self.database.animals.delete_one(query)
            return result
        except Exception:
            return "Failed to delete"
        
        
        
        
        